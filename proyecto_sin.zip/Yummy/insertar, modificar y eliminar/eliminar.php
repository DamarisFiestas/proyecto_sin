<?php
	$id=$_GET['idrestaurants'];
	include("conexion.php");

	$sql="DELETE FROM restaurants WHERE idrestaurants='".$id."'";
	$resultado=mysqli_query($conexion, $sql);

	if($resultado){
		echo "<script language='JavaScript'>
				alert('Los datos se eliminaron correctamente de la base de datos');
				location.assign('index.php');
				</script>";

	}else{
		echo "<script language='JavaScript'>
				alert('ERROR: Los datos no se eliminaron correctamente de la base de datos');
				location.assign('index.php');
				</script>";

	}
?>