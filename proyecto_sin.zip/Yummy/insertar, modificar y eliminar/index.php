<html>
<head>
	<title>Lista de restaurantes</title>
	<script type="text/javascript">
		function confirmar(){
			return confirm('¿Estas seguro de querer eliminar los datos?');
		}
	</script>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>

<?php
	include("conexion.php");
	$sql = "SELECT idrestaurants, name, adress, categories_idcategories FROM restaurants";
	$resultado=mysqli_query($conexion,$sql)
?>
	<h1>Lista de restaurante</h1>
	<a href="agregar.php">Nuevo restaurante</a><br><br>
	<table>
		<thead>
			<tr>
				<th>Id</th>
				<th>Nombre</th>
				<th>Dirección</th>
				<th>Categoría</th>
				<th>Acciones</th>
			</tr>
		</thead>
		<tbody>
			<?php
				while($filas=mysqli_fetch_assoc($resultado)){
			?>
			<tr>
				<td> <?php echo $filas['idrestaurants'] ?> </td>
				<td><?php echo $filas['name'] ?> </td>
				<td><?php echo $filas['adress'] ?> </td>
				<td><?php echo $filas['categories_idcategories'] ?> </td>
				<td>
<?php echo "<a href='editar.php?id=" .$filas['idrestaurants']."'>EDITAR</a>"; ?>
					-
<?php echo "<a href='eliminar.php?id" .$filas['idrestaurants']."'onclick='return confirmar()'>ELIMINAR</a>"; ?>
						
				</td>
			</tr>
			<?php
				}
			?>
		</tbody>
	</table>
	<?php
		mysqli_close($conexion);
	?>
</body>
</html>