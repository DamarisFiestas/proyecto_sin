<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "page_compyfood";

$conexion = mysqli_connect($servername, $username, $password, $dbname);

?>