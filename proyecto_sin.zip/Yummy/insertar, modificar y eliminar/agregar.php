<html>
<head>
	<title>AGREGAR</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
	<?php
		if(isset($_POST['enviar'])){
			$nombre=$_POST['name'];
			$dirección=$_POST['adress'];
			$categoría=$_POST['categories_idcategories'];

			include("conexion.php");
			$sql="INSERT into restaurants(name, adress, categories_idcategories) values('".$nombre."', '".$dirección."', '".$categoría."')";

			$resultado=mysqli_query($conexion, $sql);

			if($resultado){

				echo " <script language='JavaScript'> 
						alert('Los datos fueron ingresados correctamente a la base de datos');
						location.assign('index.php');
						</script>";
			}else{

				echo " <script language='JavaScript'>
						alert('ERROR: Los datos NO fueron ingresados correctamente a la base de datos');
						location.assign('index.php');
						</script>";
			}
			mysqli_close($conexion);

		}else{

	?>
	<h1>Agregar un nuevo restaurante</h1>
	<form action="<?=$SERVER['PHP_SELF']?>" method="post">
		<label>Nombre:</label>
		<input type="text" name="nombre"> <br>
		<label>Dirección:</label>
		<input type="text" name="dirección"> <br>
		<label>Categoría:</label>
		<input type="number" name="categoría"> <br>
		<input type="submit" name="enviar" value="AGREGAR">
		<a href="index.php">Regresar</a>
	</form>
	<?php
		}
	?>
</body>
</html>