<?php
	include("conexion.php");
?>
<html>
<head>
	<title>EDITAR</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
<body>
	<?php
		if(isset($_POST['enviar'])){

			$id = $_POST['idrestaurants'];
			$nombre = $_POST['nombre'];
			$dirección = $_POST['dirección'];
			$categoría = $_POST['categoría'];

			$sql = "UPDATE restaurants SET name='".$nombre."', adress='".$dirección."' WHERE idrestaurants='".$id."'";
			$resultado = mysqli_query($conexion, $sql);

			if($resultado){
				echo "<script language='JavaScript'> alert('Los datos se editaron correctamente');
						location.assign('index.php');
						</script>";

			}else{
				echo "<script language='JavaScript'> alert('ERROR: Los datos no se editaron correctamente');
						location.assign('index.php');
						</script>";

			}

		}else{

			$id = $_GET['id'];
			$sql = "SELECT * FROM restaurants WHERE idrestaurants='".$id."'";
			$resultado = mysqli_query($conexion, $sql);

			$fila = mysqli_fetch_assoc($resultado);
			$nombre = $fila['name'];
			$dirección = $fila['adress'];
			$categoría = $fila['categories_idcategories'];

			mysqli_close($conexion);
	?>
	<h1>Editar restaurante</h1>
	<form action="<?=$_SERVER['PHP_SELF'] ?>" method="post">
		<label>Nombre:</label>
		<input type="text" name="nombre" value="<?php echo $nombre; ?>"> <br>

		<label>Dirección:</label>
		<input type="text" name="dirección" value="<?php echo $dirección; ?>"> <br>

		<label>Categoría:</label>
		<input type="number" name="categoría" value="<?php echo $categoría; ?>"> <br>

		<input type="hidden" name="idrestaurants" value="<?php echo $id; ?>">

		<input type="submit" name="enviar" value="ACTUALIZAR">
		<a href="index.php">Regresar</a>

	</form>
	<?php
		}

	?>
</body>
</
