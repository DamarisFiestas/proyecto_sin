<?php
include_once("lib_php/funciones.php");

$conn = connect_bd();

$sql = "INSERT INTO requests SET ";
$sql .="name  = '".$_POST["name"]."', categoria = '".$_POST["email"]."',";
$sql .="ubicacion  = '".$_POST["phone"]."', description = '".$_POST["date"]."' , web = '".$_POST["email"]."', picture= '".$_POST["people"]."'"  ;	

echo $sql;

echo "<br>";
$stmt = $conn->prepare($sql);
$stmt->execute();

 

//header("Location: index_original.php");

?> 
