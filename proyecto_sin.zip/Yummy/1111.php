<?php
// Configuración de la conexión a la base de datos
$servername = 'localhost'; // Por ejemplo, 'localhost'
$username = 'root'; // Por ejemplo, 'root'
$password = ''; // La contraseña de tu base de datos
$bbname = 'compy'; // El nombre de tu base de datos

// Establecer la conexión con la base de datos
$conexion = new mysqli($host, $usuario, $contraseña, $base_de_datos);

// Verificar si hay errores de conexión
if ($conn->connect_error) {
    die("connection failed: " . $conn->connect_error)
}

// Categoría específica que deseas mostrar
$categoria = 'categoria';

// Consulta SQL para obtener los restaurantes de la categoría específica
$sql = "SELECT * FROM restaurantes WHERE categoria = '$criollo y marino'";

// Ejecutar la consulta y obtener el resultado
$resultado = $conexion->query($sql);

// Verificar si se encontraron resultados
if ($resultado->num_rows > 0) {
    // Mostrar los datos de los restaurantes
    while ($row = $resultado->fetch_assoc()) {
        echo "ID: " . $row['id'] . "<br>";
        echo "Nombre: " . $row['nombre'] . "<br>";
        echo "Categoría: " . $row['categoria'] . "<br>";
        echo "<br>";
    }
} else {
    echo "No se encontraron restaurantes en la categoría especificada.";
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>


<div class="row gy-5">

              <div class="col-lg-4 menu-item">
                

                <?php 

                  $sql ="SELECT  id, name, description, web, foto  From restaurants where categoria = '$criollo'";
                  $result = $conn ->query($sql);
                  
                  while($row = $result->fetch_assoc()){
                ?>
                  <div class="col-lg-4 menu-item">
                    <div class = "xyzk">
                      <a href=<?php
                          echo $row["web"]
                        ?>>
                       </a> target="_blank"> 
                        <img src="assets/img/menu/bocca-2.png">
                      </a>
                      <h4>
                        <?php
                          echo $row["name"]
                        ?>
                      </h4>
                      <p class="ingredients"><?php echo $row["description"]?></p>
                      <p class="price">
                        <a href= <?php
                          echo $row["horario"]
                        ?>

                         target="_blank">
                       </a>
                      </p>
                  <div class="tab-content" data-aos="fade-up" data-aos-delay="300">
                  </div>
                 </div> 

                <?php

                  }

                ?>
              </div>
              
            </div>


<?php 

                  $sql ="SELECT id, name FROM kind";
                  $result = $conn ->query($sql);
                  
                  while($row = $result->fetch_assoc()) {
                ?>
                <option value="Criollo"><?php echo $row["nombre"] ?> </option>
                 <?php 
                    }
                  


        <div class="tab-content" data-aos="fade-up" data-aos-delay="300">

          <div class="tab-pane fade active show" id="menu-starters">

            <div class="tab-header text-center">
              <p>Menu</p>
              <h3>Starters</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                
                <?php 

                  $sql ="SELECT  idrestaurants, name, adress, categories_idcategories, webpage, photos From restaurants Where categories_idcategories = 1 ";
                  $result = $conn ->query($sql);
                  
                  while($row = $result->fetch_assoc()){
                ?>
                  <div class="col-lg-4 menu-item">
                      <a href="<?php echo $row["webpage"]?>" target="_blank"> 
                        <img src="assets/img/rest/<?php echo $row["photo"]  
                      ?>" class="menu-img img-fluid">
                      </a>
                      <h4><?php echo $row["name"] ?>
                      </h4>
                      <p class="ingredients"><?php echo $row["adress"]?></p>
                      <p class="price"> $5.95 </p>
                
                 </div> 

                <?php

                  }

                ?>
              </div>
              
            </div>
          </div><!-- End Starter Menu Content -->

        </div>