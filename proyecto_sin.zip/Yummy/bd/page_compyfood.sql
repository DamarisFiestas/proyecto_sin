-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: page_compyfood
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `idcategories` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`idcategories`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Marino y criollo'),(2,'Carnes y brasas'),(3,'Comida regional'),(4,'Postres');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants`
--

DROP TABLE IF EXISTS `restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurants` (
  `idrestaurants` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `categories_idcategories` int(11) NOT NULL,
  `webpage` varchar(5000) NOT NULL,
  `photos` varchar(1000) NOT NULL,
  PRIMARY KEY (`idrestaurants`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants`
--

LOCK TABLES `restaurants` WRITE;
/*!40000 ALTER TABLE `restaurants` DISABLE KEYS */;
INSERT INTO `restaurants` VALUES (1,'La Bocca','Andres Avelino 234, Piura 21001',1,'http://laboccaperu.com/','fotos1'),(2,'Tayanti','Los Ejidos km1.1 a 300 metros de la UPAO, Piura 20000',3,'https://www.facebook.com/TayantiPiura/?locale=es_LA','fotos2'),(3,'La Mellicera','Av. Principal 338 Villa, Piura 20006',3,'https://www.facebook.com/p/La-Mellicera-La-Legua-100076260332271/','fotos3'),(4,'La Tomasita','Ca. Tacna 853, Piura 20004',3,'https://www.facebook.com/LaTomasitaRestaurante/?locale=es_LA','fotos4'),(5,'Gourmand','dirección5',4,'https://www.facebook.com/gourmandpiura/?locale=es_LA','fotos5'),(6,'La Bagueteria','San Miguel 222, Piura 20001',4,'https://www.facebook.com/LByDeli/?locale=es_LA','fotos6'),(7,'Antólia Café','Plaza 3 culturas, Piura 20001',4,'https://www.facebook.com/AnitaCafeCafe/','fotos7'),(8,'El Nuevo Ajicito','Gardenias Mz. B, Piura 20009',1,'https://www.facebook.com/elnuevoajicitopiura/','fotos8'),(9,'Cebichería Pedrito','Piura 20001',1,'https://www.facebook.com/Pedritodemagdalena/','fotos9'),(10,'Perupo','Calle Las Gardenias Mz G Lote 7 Urb, Piura',1,'https://www.facebook.com/perupo/?locale=es_LA','fotos10'),(11,'Eduardo El Brujo','Country 815, Piura 20001',1,'https://www.eduardoelbrujotumbes.com/nuestra-carta/','fotos11'),(12,'El Uruguayo','San Miguel 222, Piura 20001',2,'https://www.facebook.com/restaurante.eluruguayo?hc_ref=ARSgh5HuO2vRGxgIaMkLbDQDZ2mlkE9vh61cJMVZorbcGstPZncPMLytxbbYIDcfB_c&fref=nf&__xts__[0]=68.ARCTkx0N7-tIKKv-S0lahTy0vKjaaWEbcYPBO3xPxJ4ef3a09okWP-KIQYuVUrGqsqoVMVGQa8tyVhwhG3AwFfhGTATJlHwlNN5M8e6HIy13ZTkqzTZr-eU33PSuliEcKREDFBvYlSDo--dUKB9AU8ZRdEuOS3UaAKSUTPYyJskv9FGe1VOwHLg5iAAdpz1UTN0bXxI5-K8Uj2hxPxW4VYlQ5Al_WLH3_vYW4R1YO6ZaMp7Iro8RcJOiTc3QPqNO_OUg5svQwAItlSvuo_BkvfQppmZmE9zG','fotos12'),(13,'Carnes y carnadas','CPFM+Q87, Talara 20811',2,'https://carta.menu/restaurants/talara/carnes-y-carnadas','fotos13'),(14,'Pollos a la brasa Menfis','Jr. Huancavelica 735, Piura 20001',2,'https://es-la.facebook.com/polleriamenfispiura/','fotos14'),(15,'Pollo Dorado','Av. Grau 267, Piura 20001',2,'https://www.facebook.com/PolloDoradoPiura/?locale=es_LA','fotos15'),(16,'Bottega Capuccino','San Miguel 298, Piura 21001',4,'http://bottegacapuccino.com/','fotos16');
/*!40000 ALTER TABLE `restaurants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `idusers` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Anita Cortez','anita@gmail.com','123456'),(2,'Estefania Pimentel','estefania@hotmail.com','654321'),(3,'Estafano Aguirre','estefano@gmail.com','987654'),(4,'Santiago Aquino','santiago@outlook.com','456789'),(5,'Beatriz Linares','betty@gmail.com','789456'),(6,'Paloma Rodriguez','paloma@outlook.com','246813'),(7,'Carmen Ruiz','carmen@gmail.com','135792'),(8,'Karina Sanchez','kari1@hotmail.com','579321'),(9,'Pamela Renteria','pamela@hotmail.com','963258'),(10,'Carlos Perez','carlos@gmail.com','321654'),(11,'Cristina Molina','cristina@outlook.com','867530'),(12,'Juan Torres','juan@hotmail.com','112233'),(13,'Ulises Rojas','ulises@hotmail.com','445566'),(14,'Francisco Terrones','pancho@outlook.com','778899'),(15,'Dayana Mendoza','dayana@gmail.com','990099'),(16,'Doris Palomino','doris@hotmail.com','111222');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_restaurants`
--

DROP TABLE IF EXISTS `users_restaurants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_restaurants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_idusers` int(11) NOT NULL,
  `restaurants_idrestaurants` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_restaurants`
--

LOCK TABLES `users_restaurants` WRITE;
/*!40000 ALTER TABLE `users_restaurants` DISABLE KEYS */;
INSERT INTO `users_restaurants` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4),(5,5,5),(6,6,6),(7,7,7),(8,8,8),(9,9,9),(10,10,10),(11,11,11),(12,12,12),(13,13,13),(14,14,14),(15,15,15),(16,16,16),(17,8,10),(18,10,9),(19,3,4),(20,9,1),(21,12,16),(22,15,2),(23,5,11),(24,1,6),(25,2,12);
/*!40000 ALTER TABLE `users_restaurants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-16 20:41:37
